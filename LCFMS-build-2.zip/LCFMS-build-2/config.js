// Add your Supabase project details here.
// Find these in Supabase: Project Settings > API.
// The anon/publishable key is designed for browser use when Row Level Security is enabled.
// NEVER put a service_role or secret key in this file.
window.LCFMS_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
